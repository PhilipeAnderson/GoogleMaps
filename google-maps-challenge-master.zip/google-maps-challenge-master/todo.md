# Plan Of Action

- Style the individaul store item in the stores list DONE

- Show all the stores in the stores list based on real world data DONE

- Show the marker based on real world store data DONE

- Show the info window 

- MAYBE: Show the info window when you click on the indivudla store

- MAYBE: Add a beatufiful transtition on the hover of the individual store 


