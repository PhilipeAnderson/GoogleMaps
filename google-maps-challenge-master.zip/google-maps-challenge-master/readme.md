## Design Link

https://www.figma.com/file/HuauCfrLa39DV0lK76LLZb/Google-Maps?node-id=0%3A2

## FontAwesome Link

https://kit.fontawesome.com/c939d0e917.js

